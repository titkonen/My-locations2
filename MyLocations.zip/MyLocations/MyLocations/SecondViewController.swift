//
//  SecondViewController.swift
//  MyLocations
//
//  Created by Toni Itkonen on 24/02/2019.
//  Copyright © 2019 Toni Itkonen. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

